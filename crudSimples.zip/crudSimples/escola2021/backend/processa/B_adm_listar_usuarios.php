<?php
require_once "../adm/conexao.php";
$result_alunos = "SELECT * FROM escola2021";
$resultado_alunos = mysqli_query($conn, $result_alunos);
?>
<div class="container theme-showcase" role="main">
	<div class="page-header">
		<h1>Lista de Usuários</h1>
	</div>

	<!-- Botão Cadastrar -->
	<div class="row espaco">
		<div class="pull-hight">
			<a href="adm_cad_alunos.php"> <button type="button" class='btn btn-sm btn-success'>Cadastrar Alunos</button></a>
		</div>
	</div>


	<div class="row">
		<div class="col-md-12">
			<table class="table">
				<thead>
					<tr>
						<th class="text-center">Id</th>
						<th class="text-center">Nome</th>
						<th class="text-center">E-mail</th>
						<th class="text-center">CPF</th>
						<th class="text-center">Endereço</th>
						<th class="text-center">Bairro</th>
						<th class="text-center">Cidade</th>
						<th class="text-center">UF</th>
						<th class="text-center">Ações</th>
					</tr>
				</thead>
				<tbody>
					<?php while ($row_alunos = mysqli_fetch_assoc($resultado_alunos)) { ?>
						<tr>
							<td class="text-center"><?php echo $row_alunos["id"]; ?></td>
							<td class="text-center"><?php echo $row_alunos["nome"]; ?></td>
							<td class="text-center"><?php echo $row_alunos["email"]; ?></td>
							<td class="text-center"><?php echo $row_alunos["cpf"]; ?></td>
							<td class="text-center"><?php echo $row_alunos["endereco"]; ?></td>
							<td class="text-center"><?php echo $row_alunos["bairro"]; ?></td>
							<td class="text-center"><?php echo $row_alunos["cidade"]; ?></td>
							<td class="text-center"><?php echo $row_alunos["uf"]; ?></td>
							<td class="text-center">
								<a href="adm_editar_alunos.php?&id=<?php echo $row_alunos["id"]; ?>" <button type="button" class="btn btn-sm btn-info">Editar</button></a>
							</td>
							<td>
								<a href="adm_excluir_alunos.php?&id=<?php echo $row_alunos["id"]; ?>" <button type="button" class="btn btn-sm btn-danger">Excluir</button></a>
							</td>
						</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
</div>