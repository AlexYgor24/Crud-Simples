<?php
require_once "../adm/conexao.php";
$idusuario= $_GET ["id_usuario"];
$sql= "DELETE FROM usuarios WHERE id= :id";
$comando=$conn -> prepare($sql);
$comando->bindValue (":id", $idusuario);
$comando-> execute();

echo("Aluno Excluído");
header ("Location:dashboard_usuarios.php");
?>