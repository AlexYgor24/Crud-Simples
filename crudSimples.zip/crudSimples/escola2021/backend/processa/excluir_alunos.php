<?php
require_once "../adm/conexao.php";
$idaluno= $_GET ["id_aluno"];
$sql= "DELETE FROM alunos WHERE id= :id";
$comando=$conn -> prepare($sql);
$comando->bindValue (":id", $aluno);
$comando-> execute();

echo("Aluno Excluído");
header ("Location:dashboard_alunos.php");
?>