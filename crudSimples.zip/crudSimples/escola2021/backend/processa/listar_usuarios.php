<?php
require_once "..\adm\conexao.php";
$sql = 'SELECT * from usuarios';
$comando = $conn->prepare($sql);
$comando->execute();

?>
<!DOCTYPE html>
<html lang="pt-Br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Listar Usuarios</title>
</head>

<body>
    <h1> Listagem de Usuarios </h1><br>
    <table border="3" width="100%">
        <thead>
            <tr>
                <th>#ID</th>
                <th>CPF</th>
                <th>NOME</th>
                <th>SENHA</th>
                <th>tipo_user</th>
                <th>DataCadastro</th>
                <th>DataAlteração</th>
                <th>EDITAR</th>
                <th>EXCLUIR</th>
            </tr>

        </thead>
        <tbody>
            <?php
            while ($usuarios = $comando->fetch(PDO::FETCH_ASSOC)) {
            ?>
                <tr>
                    <td><?php echo $usuarios["id"];    ?></td>
                    <td><?php echo $usuarios["cpf"];    ?></td>
                    <td><?php echo  utf8_encode($usuarios["nome"]);    ?></td>
                    <td><?php echo $usuarios["senha"];    ?></td>
                    <td><?php echo $usuarios["tipo_user"];    ?></td>
                    <td><?php echo date('d/m/Y H:i:s', strtotime($usuarios["created"])); ?></td>
                    <td><?php echo date('d/m/Y H:i:s', strtotime($usuarios["modified"])); ?></td>

                    <td>
                        <a href="editar_usuarios.php?id_usuario=><?php
                                                                    echo $usuarios["id"]; ?>"> Editar</a>
                    </td>

                    <td>
                        <a href="excluir_usuarios.php?id_usuario=<?php
                                                                    echo $usuarios["id"]; ?>">Excluir</a>
                    </td>

                </tr>
            <?php
            }
            ?>




        </tbody>
</body>

</html>