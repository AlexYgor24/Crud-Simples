<?php
//importar arquivo de conexão 
    require_once "../adm/conexao.php";

    if(isset($_GET["id_alunos"])){
        $sql = "SELECT * FROM alunos WHERE id = :id";
        $comando = $conn -> prepare($sql);
        $comando -> bindValue(":id", $_GET["id_alunos"]);
        $comando -> execute();
        $idusuario = $comando -> fetch();
    }else{
        header("Location: ../listar_alunos.php");
    }
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar</title>
</head>
<body>
    <h1>Editar - CRUD SIMPLES</h1>

    <form method="POST" action="../proc_editar_alunos.php">
        <label for="nome">Nome:</label>
        <input type="text" name="nome" value="<?php echo $idusuario["nome"];?>"/>

        <label for="cpf">CPF:</label>
        <input type="text" name="cpf" value="<?php echo $idusuario["cpf"];?>"/>

        <label for="senha">Senha:</label>
        <input type="text" name="senha" value="<?php echo $idusuario["senha"];?>"/>

        <label for="tipo_user">Tipo Usuário:</label>
        <input type="text" name="tipo_user" value="<?php echo $idusuario["tipo_user"];?>"/>

        <input type="hidden" name="id_usuario" value="<?php echo $idusuario["id"];?>"/>
        <input type="submit" value="Salvar"/>
    </form>
</body>
</html>