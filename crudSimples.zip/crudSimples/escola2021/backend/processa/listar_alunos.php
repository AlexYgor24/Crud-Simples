<?php
require_once "../adm/conexao.php";
$sql = 'SELECT * from alunos';
$comando = $conn->prepare($sql);
$comando->execute();

?>
<!DOCTYPE html>
<html lang="pt-Br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Listar Alunos</title>
</head>

<body>
    <h1> Listagem de Alunos </h1><br>
    <table border="3" width="100%">
        <thead>
            <tr>
                <th>#ID</th>
                <th>NOME </th>
                <th>CPF</th>
                <th>DATA DE NASCIMENTO </th>
                <th>CEP</th>
                <th>ENDERECO</th>
                <th>BAIRRO</th>
                <th>CIDADE</th>
                <th>UF</th>
                <th>SENHA</th>
                <th>EMAIL</th>
                <th>CREATED</th>
                <th>MODIFIED</th>
                <th>EDITAR</th>
                <th>EXCLUIR</th>




            </tr>

        </thead>
        <tbody>
            <?php
            while ($alunos = $comando->fetch(PDO::FETCH_ASSOC)) {
            ?>
                <tr>
                    <td><?php echo $alunos["id"];    ?></td>
                    <td><?php echo  utf8_encode($alunos["nome"]);    ?></td>
                    <td><?php echo $alunos["cpf"];    ?></td>
                    <td><?php echo $alunos["data_nasc"];    ?></td>
                    <td><?php echo $alunos["cep"];    ?></td>
                    <td><?php echo $alunos["endereco"];    ?></td>
                    <td><?php echo $alunos["bairro"];    ?></td>
                    <td><?php echo $alunos["cidade"];    ?></td>
                    <td><?php echo $alunos["uf"];    ?></td>
                    <td><?php echo $alunos["senha"];    ?></td>
                    <td><?php echo $alunos["email"];    ?></td>
                    <td><?php echo $alunos["created"];    ?></td>
                    <td><?php echo $alunos["modified"];    ?></td>
                    <td>
                        <a href="editar_alunos.php?id_alunos=>
<?php
                echo $alunos["id"];
?>">
                            EDITAR
                        </a>
                    </td>

                    <td>
                        <a href="excluir_alunos.php?id_aluno=
 <?php echo $alunos["id"]; ?>">EXCLUIR</a>
                    </td>

                </tr>
            <?php
            }
            ?>

        </tbody>
</body>

</html>