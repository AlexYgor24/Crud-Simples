<?php
//importar arquivo de conexão 
    require_once "../adm/conexao.php";

//preparar e executar no banco de dados a inserção
    $nome = $_POST["nome"];
    $cpf = $_POST["cpf"];
    $senha = $_POST["senha"];
    $tipo_user = $_POST["tipo_user"];

    $sql = "INSERT INTO usuarios (`nome`, `cpf`, `senha`, `tipo_user`,`created`,`modified`)
     VALUES (:nome,:cpf,:senha,:tipo_user,NOW(),NOW())";
    $comando = $conn->prepare($sql);
    $comando->bindParam(":nome",$nome);
    $comando->bindParam(":cpf",$cpf);
    $comando->bindParam(":senha",$senha);
    $comando->bindParam(":tipo_user",$tipo_user);
    $comando->execute();

//retornar à página da listagem
    header("Location: ../listar_usuarios.php");
?>