<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cadastrar</title>
</head>
<body>
   <h1>Cadastrar - Crud Simples </h1>
  <form method="POST" action="../processa/proc_cadastrar.php">
  
  <label for="nome">nome:</label>
  <input type="text" name="nome"/>
  
  <label for="cpf">cpf:</label>
  <input type="number" name="cpf"/>

  
  <label for="senha">Senha:</label>
  <input type="password" name="senha"/>

  
  <label for="tipo_user">tipo_user:</label>
  <input type="number" name="tipo_user"/>

  <input type="submit" value="Cadastrar"/>
</body>
</html>